#!/bin/bash


zip -r examen.zip . -x "*.DS_Store" "*/__MACOSX/*"
