#!/bin/bash

zip -r ExamenOODB.zip . -x "*.DS_Store" "*/__MACOSX/*" "*.zip"  "*node_modules*" "*.build/*"